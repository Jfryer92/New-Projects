﻿internal class Collider3D
{
}